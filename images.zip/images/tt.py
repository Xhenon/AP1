import png
import random

w = png.Writer(1920 , 1080)
l = []
    
for i in range(1080):
    l.append(tuple(random.randint(0 , 255) for j in range(1920*3)))


f= open('test.png' , 'wb')
w.write(f , l)
f.close()
import copy
import random
import time
import multiprocessing as mp

def stuff(x , y):
    return ((x ,y) , x*y)

    
if __name__ == '__main__':
    ti= time.time()
    pool = mp.Pool(processes = mp.cpu_count())
    width = 20
    height = 10
    l = []
    for i in range(width):
        for j in range(height):
            l.append((i , j))
    res = pool.starmap(stuff , l)
    print(str(res[41][1]) + " " +  str(res[41][0]))
    #print(res)
    print(time.time()-ti)

